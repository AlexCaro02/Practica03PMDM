package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AltaActivity extends AppCompatActivity {

    TextView nombreTextView;
    TextView correoTextView;
    TextView fechaTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_altas);
        nombreTextView = (TextView) findViewById(R.id.nombreTextView);
        correoTextView = (TextView) findViewById(R.id.emailTextView);
        fechaTextView = (TextView) findViewById(R.id.fechaTextView);
    }
    public void cancelarBoton(View v) {
        finish();
    }
    public void aceptarBoton(View v) {
        if(nombreTextView.getText().toString().compareTo("")==0
                ||correoTextView.getText().toString().compareTo("")==0
                ||fechaTextView.getText().toString().compareTo("")==0){
            Log.e("NODATA","Error: no se han insertado datos");
        }
        else {
            Intent data = new Intent(this, MainActivity.class);
            Bundle extras = new Bundle();
            extras.putString("NOMBRE", nombreTextView.getText().toString());
            extras.putString("EMAIL", correoTextView.getText().toString());
            extras.putString("FECHA", fechaTextView.getText().toString());
            data.putExtras(extras);

            setResult(RESULT_OK, data);
            Log.i("SUCCESS","Se han obtenido los datos correctamente");
        }
        finish();
    }
}