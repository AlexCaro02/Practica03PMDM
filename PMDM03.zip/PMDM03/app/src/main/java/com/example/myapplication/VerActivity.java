package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class VerActivity extends AppCompatActivity {

    EditText nombreTextView;
    EditText correoTextView;
    EditText fechaTextView;
    EditText generoTextView;
    EditText alturaTextView;
    EditText fecha2TextView;
    EditText ratingTextView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver);
        nombreTextView = (EditText) findViewById(R.id.nombreTextView);
        correoTextView = (EditText) findViewById(R.id.emailTextView);
        fechaTextView = (EditText) findViewById(R.id.fechaTextView);
        generoTextView = (EditText) findViewById(R.id.generoTextView);
        alturaTextView = (EditText) findViewById(R.id.alturaTextView);
        fecha2TextView = (EditText) findViewById(R.id.fecha2TextView);
        ratingTextView = (EditText) findViewById(R.id.ratingTextView);

        nombreTextView.setText(getIntent().getStringExtra("NOMBRE"));
        correoTextView.setText(getIntent().getStringExtra("EMAIL"));
        fechaTextView.setText(getIntent().getStringExtra("FECHA"));
        generoTextView.setText(getIntent().getStringExtra("GENERO"));
        alturaTextView.setText(getIntent().getStringExtra("ALTURA"));
        fecha2TextView.setText(getIntent().getStringExtra("FECHA2"));
        ratingTextView.setText(getIntent().getStringExtra("RATING"));





    }
    public void cancelarBoton(View v) {
        finish();
    }
}